#!/bin/sh
serverless config credentials --provider aws --key AKIARS6O5W2C6DWN6S4E --secret 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


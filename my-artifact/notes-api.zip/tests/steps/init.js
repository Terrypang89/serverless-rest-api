"use strict";

const init = async () => {
    require("dotenv").config();
};

module.exports = init;